﻿
namespace ContaCorrente
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblNumConta = new System.Windows.Forms.Label();
            this.lblTitular = new System.Windows.Forms.Label();
            this.lblSaldo = new System.Windows.Forms.Label();
            this.lblNumeroConta = new System.Windows.Forms.Label();
            this.lblNomeTitular = new System.Windows.Forms.Label();
            this.lblSaldo2 = new System.Windows.Forms.Label();
            this.txtNumConta = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMovimentacao = new System.Windows.Forms.TextBox();
            this.btnDepositar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.rbtnEntrada = new System.Windows.Forms.RadioButton();
            this.rbtnSaida = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número da conta:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome do titular:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Movimentação:";
            // 
            // lblNumConta
            // 
            this.lblNumConta.AutoSize = true;
            this.lblNumConta.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumConta.Location = new System.Drawing.Point(12, 195);
            this.lblNumConta.Name = "lblNumConta";
            this.lblNumConta.Size = new System.Drawing.Size(170, 24);
            this.lblNumConta.TabIndex = 3;
            this.lblNumConta.Text = "Número da conta:";
            // 
            // lblTitular
            // 
            this.lblTitular.AutoSize = true;
            this.lblTitular.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitular.Location = new System.Drawing.Point(12, 235);
            this.lblTitular.Name = "lblTitular";
            this.lblTitular.Size = new System.Drawing.Size(155, 24);
            this.lblTitular.TabIndex = 4;
            this.lblTitular.Text = "Nome do titular:";
            // 
            // lblSaldo
            // 
            this.lblSaldo.AutoSize = true;
            this.lblSaldo.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo.Location = new System.Drawing.Point(12, 277);
            this.lblSaldo.Name = "lblSaldo";
            this.lblSaldo.Size = new System.Drawing.Size(66, 24);
            this.lblSaldo.TabIndex = 5;
            this.lblSaldo.Text = "Saldo:";
            // 
            // lblNumeroConta
            // 
            this.lblNumeroConta.AutoSize = true;
            this.lblNumeroConta.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroConta.Location = new System.Drawing.Point(188, 195);
            this.lblNumeroConta.Name = "lblNumeroConta";
            this.lblNumeroConta.Size = new System.Drawing.Size(0, 24);
            this.lblNumeroConta.TabIndex = 6;
            // 
            // lblNomeTitular
            // 
            this.lblNomeTitular.AutoSize = true;
            this.lblNomeTitular.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeTitular.Location = new System.Drawing.Point(173, 235);
            this.lblNomeTitular.Name = "lblNomeTitular";
            this.lblNomeTitular.Size = new System.Drawing.Size(0, 24);
            this.lblNomeTitular.TabIndex = 7;
            // 
            // lblSaldo2
            // 
            this.lblSaldo2.AutoSize = true;
            this.lblSaldo2.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo2.Location = new System.Drawing.Point(84, 277);
            this.lblSaldo2.Name = "lblSaldo2";
            this.lblSaldo2.Size = new System.Drawing.Size(21, 24);
            this.lblSaldo2.TabIndex = 8;
            this.lblSaldo2.Text = "0";
            // 
            // txtNumConta
            // 
            this.txtNumConta.Location = new System.Drawing.Point(188, 13);
            this.txtNumConta.Name = "txtNumConta";
            this.txtNumConta.Size = new System.Drawing.Size(151, 22);
            this.txtNumConta.TabIndex = 9;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(173, 50);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(166, 22);
            this.txtNome.TabIndex = 10;
            // 
            // txtMovimentacao
            // 
            this.txtMovimentacao.Location = new System.Drawing.Point(164, 91);
            this.txtMovimentacao.Name = "txtMovimentacao";
            this.txtMovimentacao.Size = new System.Drawing.Size(175, 22);
            this.txtMovimentacao.TabIndex = 11;
            // 
            // btnDepositar
            // 
            this.btnDepositar.BackColor = System.Drawing.Color.Silver;
            this.btnDepositar.Font = new System.Drawing.Font("Bahnschrift", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDepositar.ForeColor = System.Drawing.Color.Black;
            this.btnDepositar.Location = new System.Drawing.Point(193, 134);
            this.btnDepositar.Name = "btnDepositar";
            this.btnDepositar.Size = new System.Drawing.Size(146, 43);
            this.btnDepositar.TabIndex = 12;
            this.btnDepositar.Text = "Movimentar";
            this.btnDepositar.UseVisualStyleBackColor = false;
            this.btnDepositar.Click += new System.EventHandler(this.btnDepositar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Silver;
            this.btnLimpar.Font = new System.Drawing.Font("Bahnschrift", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.Black;
            this.btnLimpar.Location = new System.Drawing.Point(343, 134);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(146, 43);
            this.btnLimpar.TabIndex = 14;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // rbtnEntrada
            // 
            this.rbtnEntrada.AutoSize = true;
            this.rbtnEntrada.Location = new System.Drawing.Point(12, 124);
            this.rbtnEntrada.Name = "rbtnEntrada";
            this.rbtnEntrada.Size = new System.Drawing.Size(85, 21);
            this.rbtnEntrada.TabIndex = 15;
            this.rbtnEntrada.TabStop = true;
            this.rbtnEntrada.Text = "Depósito";
            this.rbtnEntrada.UseVisualStyleBackColor = true;
            // 
            // rbtnSaida
            // 
            this.rbtnSaida.AutoSize = true;
            this.rbtnSaida.Location = new System.Drawing.Point(12, 156);
            this.rbtnSaida.Name = "rbtnSaida";
            this.rbtnSaida.Size = new System.Drawing.Size(83, 21);
            this.rbtnSaida.TabIndex = 16;
            this.rbtnSaida.TabStop = true;
            this.rbtnSaida.Text = "Retirada";
            this.rbtnSaida.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 317);
            this.Controls.Add(this.rbtnSaida);
            this.Controls.Add(this.rbtnEntrada);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnDepositar);
            this.Controls.Add(this.txtMovimentacao);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtNumConta);
            this.Controls.Add(this.lblSaldo2);
            this.Controls.Add(this.lblNomeTitular);
            this.Controls.Add(this.lblNumeroConta);
            this.Controls.Add(this.lblSaldo);
            this.Controls.Add(this.lblTitular);
            this.Controls.Add(this.lblNumConta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conta Corrente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblNumConta;
        private System.Windows.Forms.Label lblTitular;
        private System.Windows.Forms.Label lblSaldo;
        private System.Windows.Forms.Label lblNumeroConta;
        private System.Windows.Forms.Label lblNomeTitular;
        private System.Windows.Forms.Label lblSaldo2;
        private System.Windows.Forms.TextBox txtNumConta;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMovimentacao;
        private System.Windows.Forms.Button btnDepositar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.RadioButton rbtnEntrada;
        private System.Windows.Forms.RadioButton rbtnSaida;
    }
}

