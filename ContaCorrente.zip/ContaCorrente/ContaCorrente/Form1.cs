﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContaCorrente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtMovimentacao.Text = "";
            rbtnEntrada.Checked = false;
            rbtnSaida.Checked = false;
        }

        private void btnDepositar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            int numConta = int.Parse(txtNumConta.Text);
            double movimentacao = double.Parse(txtMovimentacao.Text), saldo = double.Parse(lblSaldo2.Text);

            if (rbtnEntrada.Checked == true)
            {
                saldo += movimentacao;
                lblSaldo2.Text = saldo.ToString("C");
                lblNumeroConta.Text = numConta.ToString();
                lblNomeTitular.Text = nome;
            }
            else if (rbtnSaida.Checked == true)
            {
                saldo -= movimentacao;
                lblSaldo2.Text = saldo.ToString("C");
                lblNumeroConta.Text = numConta.ToString();
                lblNomeTitular.Text = nome;
            }
        }
    }
}
