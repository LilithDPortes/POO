﻿
namespace LucroAula2602
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_nome = new System.Windows.Forms.Label();
            this.txt_nome = new System.Windows.Forms.TextBox();
            this.lbl_classificacao = new System.Windows.Forms.Label();
            this.txt_preco = new System.Windows.Forms.TextBox();
            this.rbtn_linhap = new System.Windows.Forms.RadioButton();
            this.rbtn_linhas = new System.Windows.Forms.RadioButton();
            this.lbl_preco = new System.Windows.Forms.Label();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.lbl_lucro = new System.Windows.Forms.Label();
            this.txt_lucro = new System.Windows.Forms.TextBox();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.lbl_revenda = new System.Windows.Forms.Label();
            this.txt_revenda = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_titulo.Location = new System.Drawing.Point(131, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(247, 32);
            this.lbl_titulo.TabIndex = 0;
            this.lbl_titulo.Text = "Lucro de Vendas";
            // 
            // lbl_nome
            // 
            this.lbl_nome.AutoSize = true;
            this.lbl_nome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nome.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_nome.Location = new System.Drawing.Point(12, 54);
            this.lbl_nome.Name = "lbl_nome";
            this.lbl_nome.Size = new System.Drawing.Size(186, 23);
            this.lbl_nome.TabIndex = 1;
            this.lbl_nome.Text = "Nome do produto:";
            // 
            // txt_nome
            // 
            this.txt_nome.Location = new System.Drawing.Point(215, 54);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(163, 22);
            this.txt_nome.TabIndex = 2;
            // 
            // lbl_classificacao
            // 
            this.lbl_classificacao.AutoSize = true;
            this.lbl_classificacao.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_classificacao.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_classificacao.Location = new System.Drawing.Point(12, 92);
            this.lbl_classificacao.Name = "lbl_classificacao";
            this.lbl_classificacao.Size = new System.Drawing.Size(260, 23);
            this.lbl_classificacao.TabIndex = 3;
            this.lbl_classificacao.Text = "Classificação do produto:";
            // 
            // txt_preco
            // 
            this.txt_preco.Location = new System.Drawing.Point(215, 137);
            this.txt_preco.Name = "txt_preco";
            this.txt_preco.Size = new System.Drawing.Size(163, 22);
            this.txt_preco.TabIndex = 4;
            // 
            // rbtn_linhap
            // 
            this.rbtn_linhap.AutoSize = true;
            this.rbtn_linhap.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn_linhap.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rbtn_linhap.Location = new System.Drawing.Point(286, 91);
            this.rbtn_linhap.Name = "rbtn_linhap";
            this.rbtn_linhap.Size = new System.Drawing.Size(90, 24);
            this.rbtn_linhap.TabIndex = 5;
            this.rbtn_linhap.TabStop = true;
            this.rbtn_linhap.Text = "1ª linha\r\n";
            this.rbtn_linhap.UseVisualStyleBackColor = true;
            // 
            // rbtn_linhas
            // 
            this.rbtn_linhas.AutoSize = true;
            this.rbtn_linhas.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn_linhas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rbtn_linhas.Location = new System.Drawing.Point(382, 91);
            this.rbtn_linhas.Name = "rbtn_linhas";
            this.rbtn_linhas.Size = new System.Drawing.Size(90, 24);
            this.rbtn_linhas.TabIndex = 6;
            this.rbtn_linhas.TabStop = true;
            this.rbtn_linhas.Text = "2ª linha\r\n";
            this.rbtn_linhas.UseVisualStyleBackColor = true;
            // 
            // lbl_preco
            // 
            this.lbl_preco.AutoSize = true;
            this.lbl_preco.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_preco.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_preco.Location = new System.Drawing.Point(12, 137);
            this.lbl_preco.Name = "lbl_preco";
            this.lbl_preco.Size = new System.Drawing.Size(187, 23);
            this.lbl_preco.TabIndex = 7;
            this.lbl_preco.Text = "Preço do produto:";
            // 
            // btn_calcular
            // 
            this.btn_calcular.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_calcular.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calcular.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_calcular.Location = new System.Drawing.Point(137, 275);
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.Size = new System.Drawing.Size(92, 32);
            this.btn_calcular.TabIndex = 8;
            this.btn_calcular.Text = "Calcular";
            this.btn_calcular.UseVisualStyleBackColor = false;
            this.btn_calcular.Click += new System.EventHandler(this.btn_calcular_Click);
            // 
            // lbl_lucro
            // 
            this.lbl_lucro.AutoSize = true;
            this.lbl_lucro.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lucro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_lucro.Location = new System.Drawing.Point(12, 231);
            this.lbl_lucro.Name = "lbl_lucro";
            this.lbl_lucro.Size = new System.Drawing.Size(73, 23);
            this.lbl_lucro.TabIndex = 9;
            this.lbl_lucro.Text = "Lucro:";
            // 
            // txt_lucro
            // 
            this.txt_lucro.Location = new System.Drawing.Point(109, 234);
            this.txt_lucro.Name = "txt_lucro";
            this.txt_lucro.Size = new System.Drawing.Size(163, 22);
            this.txt_lucro.TabIndex = 10;
            // 
            // btn_limpar
            // 
            this.btn_limpar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_limpar.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_limpar.Location = new System.Drawing.Point(286, 275);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(92, 32);
            this.btn_limpar.TabIndex = 11;
            this.btn_limpar.Text = "Limpar";
            this.btn_limpar.UseVisualStyleBackColor = false;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click);
            // 
            // lbl_revenda
            // 
            this.lbl_revenda.AutoSize = true;
            this.lbl_revenda.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_revenda.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_revenda.Location = new System.Drawing.Point(12, 183);
            this.lbl_revenda.Name = "lbl_revenda";
            this.lbl_revenda.Size = new System.Drawing.Size(190, 23);
            this.lbl_revenda.TabIndex = 12;
            this.lbl_revenda.Text = "Preço de revenda:";
            // 
            // txt_revenda
            // 
            this.txt_revenda.Location = new System.Drawing.Point(215, 183);
            this.txt_revenda.Name = "txt_revenda";
            this.txt_revenda.Size = new System.Drawing.Size(163, 22);
            this.txt_revenda.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(490, 331);
            this.Controls.Add(this.txt_revenda);
            this.Controls.Add(this.lbl_revenda);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.txt_lucro);
            this.Controls.Add(this.lbl_lucro);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.lbl_preco);
            this.Controls.Add(this.rbtn_linhas);
            this.Controls.Add(this.rbtn_linhap);
            this.Controls.Add(this.txt_preco);
            this.Controls.Add(this.lbl_classificacao);
            this.Controls.Add(this.txt_nome);
            this.Controls.Add(this.lbl_nome);
            this.Controls.Add(this.lbl_titulo);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lucro de Vendas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_nome;
        private System.Windows.Forms.TextBox txt_nome;
        private System.Windows.Forms.Label lbl_classificacao;
        private System.Windows.Forms.TextBox txt_preco;
        private System.Windows.Forms.RadioButton rbtn_linhap;
        private System.Windows.Forms.RadioButton rbtn_linhas;
        private System.Windows.Forms.Label lbl_preco;
        private System.Windows.Forms.Button btn_calcular;
        private System.Windows.Forms.Label lbl_lucro;
        private System.Windows.Forms.TextBox txt_lucro;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.Label lbl_revenda;
        private System.Windows.Forms.TextBox txt_revenda;
    }
}

