﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LucroAula2602
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_calcular_Click(object sender, EventArgs e)
        {
            string nome;
            double preco, lucro = 0, revenda = 0;

            nome = txt_nome.Text;
            preco = double.Parse(txt_preco.Text);
            if (rbtn_linhap.Checked == true)
            {
                revenda = preco * 1.45;
                lucro = revenda - preco;
            }
            else if (rbtn_linhas.Checked == true)
                {
                    revenda = preco * 1.30;
                    lucro = revenda - preco;
                }

            lbl_lucro.Text = lucro.ToString("C");
            lbl_revenda.Text = revenda.ToString("C");
        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {
            txt_nome.Text = "";
            rbtn_linhap.Checked = false;
            rbtn_linhas.Checked = false;
            txt_lucro.Text = "";
            txt_preco.Text = "";
            txt_revenda.Text = "";
        }
    }
}
