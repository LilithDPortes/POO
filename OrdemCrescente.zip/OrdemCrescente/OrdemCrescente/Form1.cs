﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrdemCrescente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int num1 = 0, num2 = 0, num3 = 0;

            num1 = int.Parse(txtNumUm.Text);
            num2 = int.Parse(txtNumDois.Text);
            num3 = int.Parse(txtNumTres.Text);

            if (num1 < num2 && num1 < num3 && num2 < num3)
            {
                lblNum1.Text = num1.ToString();
                lblNum2.Text = num2.ToString();
                lblNum3.Text = num3.ToString();
            }
            else if (num2 < num1 && num2 < num3 && num1 < num3)
            {
                lblNum1.Text = num2.ToString();
                lblNum2.Text = num1.ToString();
                lblNum3.Text = num3.ToString();
            }
            else if (num3 < num1 && num3 < num2 && num1 < num2)
            {
                lblNum1.Text = num3.ToString();
                lblNum2.Text = num1.ToString();
                lblNum3.Text = num2.ToString();
            }
            else if (num3 < num1 && num3 < num2 && num2 < num1)
            {
                lblNum1.Text = num3.ToString();
                lblNum2.Text = num2.ToString();
                lblNum3.Text = num1.ToString();
            }
            else if (num2 < num1 && num2 < num3 && num3 < num1)
            {
                lblNum1.Text = num2.ToString();
                lblNum2.Text = num3.ToString();
                lblNum3.Text = num1.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblNum1.Text = "0";
            lblNum2.Text = "0";
            lblNum3.Text = "0";
            txtNumUm.Text = "";
            txtNumDois.Text = "";
            txtNumTres.Text = "";
        }
    }
}
