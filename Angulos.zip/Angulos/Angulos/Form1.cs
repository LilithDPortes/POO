﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Angulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double angulo1, angulo2, angulo3;

            angulo1 = double.Parse(txtAngulo1.Text);
            angulo2 = double.Parse(txtAngulo2.Text);
            angulo3 = double.Parse(txtAngulo3.Text);

            if (angulo1 == 90 || angulo2 == 90 || angulo3 == 90)
            {
                lblTriangulo.Text = "Retângulo";
            }
            else if (angulo1 > 90 || angulo2 > 90 || angulo3 > 90)
            {
                lblTriangulo.Text = "Obtusângulo";
            }
            else if (angulo1 < 90 && angulo2 < 90 && angulo3 < 90)
            {
                lblTriangulo.Text = "Acutângulo";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblTriangulo.Text = "";
            txtAngulo1.Text = "";
            txtAngulo2.Text = "";
            txtAngulo3.Text = "";
        }
    }
}
